﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

public partial class Company_PostJob : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    int Op = 0;
    string strJType="";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnPost_Click(object sender, EventArgs e)
    {
        int resDate=DateTime.Compare(Convert.ToDateTime(txtDate.Text.ToString()),Convert.ToDateTime(System.DateTime.Now.ToString("dd-MM-yyyy")));
        if (!rdbFull.Checked && !rdbPart.Checked && !rdbContract.Checked)
        {
            lblError.Text = "Please Mention the Job Type";
        }
        else
	    {
            if (rdbFull.Checked)
	        {
		        strJType=rdbFull.Text.Trim().ToUpper();
	        }
		    else if (rdbPart.Checked)
	        {
		        strJType=rdbPart.Text.Trim().ToUpper();
	        } 
            else 
            {
                strJType=rdbContract.Text.Trim().ToUpper();   
            }             
	    }

        if (ddIType.SelectedIndex.Equals(0))
        {
            lblError.Text = "Select Industry Type From List";
        }
        else if (ddNEyears.SelectedIndex.Equals(0))
        {
            lblError.Text = "Select Years Experience of From List";
        }
        else if (cmbCLocation.SelectedIndex.Equals(0))
        {
            lblError.Text = "Select Location From List";
        }
        else if (resDate < 0 || resDate == 0)
        {
            lblError.Text = "Not Possible";
        }
        else
        {
            Response.Write("hello");
            try
            {
                string strSql = String.Format("insert into tblJobPost(jbType,jbDesignation,jbIndusType,jbSkills,jbDesc,jbReqExp,jbCTC,jbLocation,jbCompDesc,jbActiveDate,usrId) values(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j,@k)");
                MySqlCommand objCmd = new MySqlCommand(strSql, objCon);
                objCmd.Parameters.AddWithValue("@a", strJType);
                objCmd.Parameters.AddWithValue("@b",txtDesgination.Text.ToString().ToUpper().Trim());
                objCmd.Parameters.AddWithValue("@c",ddIType.SelectedValue.ToString());
                objCmd.Parameters.AddWithValue("@d",txtSkills.Text.ToString().Trim());
                objCmd.Parameters.AddWithValue("@e",txtJDesc.Text.ToString().Trim());
                objCmd.Parameters.AddWithValue("@f",ddNEyears.SelectedValue.ToString());
                objCmd.Parameters.AddWithValue("@g",txtCTC.Text.ToString().Trim());
                objCmd.Parameters.AddWithValue("@h",cmbCLocation.SelectedValue.ToString());
                objCmd.Parameters.AddWithValue("@i",txtCDesc.Text.ToString().Trim());
                objCmd.Parameters.AddWithValue("@j",txtDate.Text.Trim());
                objCmd.Parameters.AddWithValue("@k","3");                
                Op=objCmd.ExecuteNonQuery();
                if (Op>0)
	            {
		            Response.Write("<script>alert('Job Posted Successfully,Wait for Admin to Approve!<br/>Thanks');window.location.replace('../Company/PostJob.aspx');</script>");
	            }
                else
	            {
                    lblError.Text="Prob Occur";
	            }
            }
            catch (Exception objEx)
            {
                Response.Write(objEx.ToString());
            }           
            DbConfig.closeConnection();
        }
    }
}