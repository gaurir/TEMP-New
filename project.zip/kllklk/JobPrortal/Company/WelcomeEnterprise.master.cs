﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_WelcomeEnterprise : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["User"] != null && Session["UsrType"] != null && Session["UsrID"] != null)
        {
            string usrType = "Company";
            int usrID = Convert.ToInt32(Session["UsrID"].ToString());
            if (Session["UsrType"].Equals(usrType) && usrID != 0)
            {
                hpUser.Text = Session["User"].ToString();
                // GetUserDetails(Session["User"].ToString(), usrID);
            }
            else
            {
                Response.Write("~/welcome.aspx");
            }
        }
        else
        {
            Response.Redirect("~/welcome.aspx");
        }
    }
}
