﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (!txt_npassword.Text.Equals(txt_ccpassword.Text))
        {
            lblError.Text = "New Password and Confirm Password Not Matched";
        }
    }
}