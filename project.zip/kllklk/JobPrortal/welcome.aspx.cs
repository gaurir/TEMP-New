﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class welcome : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    int Op = 0;
    protected void Page_Init(object sender, EventArgs e)
    {

        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            Session.Clear();
            Session.Abandon();
        }        
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtPwd.Text.Length != 0 && txtUser.Text.Length != 0)
        {
            try
            {
                MySqlCommand objCmd = new MySqlCommand("spUserLogin", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("p_UsrInput", txtUser.Text.Trim());
                objCmd.Parameters.AddWithValue("p_Password", txtPwd.Text.Trim());
                objCmd.Parameters.Add("@p_UsrID", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                objCmd.Parameters.Add("@p_UserName", MySqlDbType.VarChar).Direction = ParameterDirection.Output;
                objCmd.Parameters.Add("@p_UsrType", MySqlDbType.VarChar).Direction = ParameterDirection.Output;
                objCmd.Parameters.Add("@p_OutRes", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                objCmd.ExecuteNonQuery();
                Op = Convert.ToInt32(objCmd.Parameters["@p_OutRes"].Value.ToString());
                switch (Op)
                {
                    case 0:
                        lblErr.Text = "Please check Username and Password not exist!! ";
                        break;
                    case 101:
                        //Session["Users"] = objCmd.Parameters["@p_UserName"].Value.ToString();
                        //if (Session["Users"] != null)
                        //{
                        //    Response.Redirect("UpdateProfile.aspx");
                        //}
                        //break;
                    case 201:
                        Session["User"] =(string)objCmd.Parameters["@p_UserName"].Value;
                        Session["UsrType"] = (string)objCmd.Parameters["@p_UsrType"].Value;
                        int usrID = Convert.ToInt32(objCmd.Parameters["@p_UsrID"].Value.ToString());
                        if ((Session["User"] != null) && (usrID != 0) && (Session["UsrType"] != null))
                        {
                            if (Session["UsrType"].ToString()=="Job Seeker")
                            {
                                Session["UsrID"] = usrID.ToString();
                                Response.Redirect("RegisteredUser.aspx");
                            }
                            else
                            {
                                Session["UsrID"] = usrID.ToString();
                                Response.Redirect("Company/WelcomeIndustry.aspx");
                            }
                        }
                        break;
                }
                DbConfig.closeConnection();
            }
            catch (Exception objEx)
            {
                Response.Write(objEx.ToString());
            }
        }
    }
}