﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.IO;

public partial class LCompanyInfo : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    string FilNameEx = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UsrID"] != null)
        {
            HiddenField1.Value = Session["UsrID"].ToString();
        }
        else
        {
            Response.Redirect("CreateAccount.aspx");
        }   
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (txtUrl.Text.Length==0 || txtUrl.Text.Length<=6)
        {
            lblErr.Text = "Enter Proper Company Url";
        }
        try
        {
            MySqlCommand objCmd = new MySqlCommand("Update tblimgcv SET compUrl=@curl where usrID=@ID", objCon);
            objCmd.Parameters.AddWithValue("@curl", txtUrl.Text.Trim());
            objCmd.Parameters.AddWithValue("@Id", HiddenField1.Value.ToString());
            if (objCmd.ExecuteNonQuery() > 0)
            {
                Session.Abandon();
                Response.Write("<script>alert('Succesfull In Account Creation Now Please Login');window.location.replace('welcome.aspx');</script>");
            }
            else
            {
                lblErr.Text = "failed";
            }
        }
        catch (Exception objEx)
        {
            Response.Write(objEx.ToString());
        }                    
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            if (IsPostBack)
            {
                if (flUploadImg.HasFile)
                {
                    string ext = Path.GetExtension(flUploadImg.PostedFile.FileName);

                    string[] allowedExtenstions = new string[] { ".png", ".jpg", ".jpeg" };

                    if (allowedExtenstions.Contains(ext))
                    {
                        FilNameEx = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                        flUploadImg.SaveAs(MapPath("~/image/compLogo/" + FilNameEx + ext));
                        FilNameEx = picEmp.ImageUrl = "~/image/compLogo/" + FilNameEx + ext;

                        MySqlCommand objCmd = new MySqlCommand("Insert Into tblimgcv(usrIMG,usrID) values(@Img,@Id)", objCon);
                        objCmd.Parameters.AddWithValue("@Img", FilNameEx);
                        objCmd.Parameters.AddWithValue("@Id", HiddenField1.Value.ToString());
                        if (objCmd.ExecuteNonQuery() > 0)
                        {
                            lblErr.Text = "Image Uploaded Successfully";
                        }
                        else
                        {
                            lblErr.Text = "Image Uploaded failed";
                        }
                        flUploadImg.Visible = false;
                        this.Visible = false;
                    }
                    else
                    {
                        lblErr.Text = "Please Upload Image File Only";
                    }
                }
            }
        }
        catch (Exception objEx)
        {
            Response.Write(objEx.ToString());
        }               
    }
}