﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;


public partial class CreateAccount : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    int Op = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        if (cmbCLocation.SelectedIndex.Equals(0))
        {
            lblErr.Text = "Select proper location.";
        }
        else if (rdbFemale.Checked==false && rdbMale.Checked==false)
        {
            lblErr.Text = "Select your gender";
        }
        else if (rdbCompany.Checked==false && rdbJSeeker.Checked==false)
        {
            lblErr.Text = "Select your application type";
        }
        else if(txtcpwd.Text.Equals(txtpwd.Text))
        {
            try
            {
                MySqlCommand objCmd = new MySqlCommand("spUserCreation", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("p_FName", txtfn.Text.Trim());
                objCmd.Parameters.AddWithValue("p_LName", txtln.Text.Trim());
                objCmd.Parameters.AddWithValue("p_Age", txtage.Text.Trim());
                objCmd.Parameters.AddWithValue("p_Gender", rdbMale.Checked ? rdbMale.Text.ToUpper() : rdbFemale.Text.ToUpper());
                objCmd.Parameters.AddWithValue("p_Type", rdbJSeeker.Checked ? rdbJSeeker.Text.Trim() : rdbCompany.Text.Trim());
                objCmd.Parameters.AddWithValue("p_Mobile", txtMno.Text.Trim());
                objCmd.Parameters.AddWithValue("p_Username", txtUsrname.Text.Trim());
                objCmd.Parameters.AddWithValue("p_Email", txtEmail.Text.Trim());
                objCmd.Parameters.AddWithValue("p_CLocation", cmbCLocation.Text.Trim().ToUpper());
                objCmd.Parameters.AddWithValue("p_Password", txtpwd.Text.Trim());
                objCmd.Parameters.Add("p_OutRes", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                objCmd.Parameters.Add("p_LastUsrId", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                objCmd.ExecuteNonQuery();
                Op = Convert.ToInt32(objCmd.Parameters["p_OutRes"].Value.ToString());
                switch (Op)
                {
                    case 0:
                        if (rdbJSeeker.Checked)
                        {
                            Session["usrID"] = objCmd.Parameters["p_LastUsrId"].Value.ToString();
                            Response.Redirect("ProfessionalDetails.aspx");
                        }
                        else
                        {
                            Session["usrID"] = objCmd.Parameters["p_LastUsrId"].Value.ToString();
                            Response.Redirect("InsertCompanyDetails.aspx");
                        }
                        break;
                    case 101:
                        lblErr.Text = "This Email is already registered";
                        break;
                    case 301:
                        lblErr.Text = "This Username is already registered";
                        break;
                    case 201:
                        lblErr.Text = "This Mobile Number is already registered";
                        break;                    
                }
                DbConfig.closeConnection();
            }
            catch (Exception objEx)
            {
                Response.Write(objEx.ToString());
            }
        }
        else
        {
            lblErr.Text = "Password and Confirm password Not match";
        }
    }
}