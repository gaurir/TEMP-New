﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class InsertCompanyDetails : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    int Op = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UsrID"] != null)
        {
            HiddenField1.Value = Session["UsrID"].ToString();            
        }
        else
        {
            Response.Redirect("CreateAccount.aspx");
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
             MySqlCommand objCmd = new MySqlCommand("spFillCompDetails", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("p_usrId", Convert.ToInt32(HiddenField1.Value.Trim()));
                objCmd.Parameters.AddWithValue("p_compName", txtCompName.Text.Trim());
                objCmd.Parameters.AddWithValue("p_cIndusType", ddIType.Text.Trim());
                objCmd.Parameters.AddWithValue("p_compType", rdbCom.Checked ? rdbCom.Text.ToUpper() : rdbCon.Text.ToUpper());               
                objCmd.Parameters.AddWithValue("p_compAddress",txtAdd.Text.Trim().ToUpper());
                objCmd.Parameters.AddWithValue("p_compPincode", txtPin.Text.Trim());
                objCmd.Parameters.AddWithValue("p_compContactP", txtCperson.Text.Trim());
                objCmd.Parameters.AddWithValue("p_compContactNum", txtCNum.Text.Trim());
                objCmd.Parameters.Add("p_OutRes", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                objCmd.ExecuteNonQuery();
                Op = Convert.ToInt32(objCmd.Parameters["p_OutRes"].Value.ToString());
                switch (Op)
                {
                    case 0:
                        Response.Redirect("LCompanyInfo.aspx");
                        break;
                    case 101:                        
                        lblErr.Text = "This Company name is already registered";
                        break;
                    default:
                        lblErr.Text = "Something went wrong";
                    break;
                }
                DbConfig.closeConnection();
            }
            catch (Exception objEx)
            {
                Response.Write(objEx.ToString());
            }
        }        
    }
