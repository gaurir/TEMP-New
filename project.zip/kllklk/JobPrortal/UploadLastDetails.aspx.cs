﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.IO;

public partial class UploadLastDetails : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    string FilNameEx = "", ResumeEx="";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usrID"] != null)
        {
            HiddenField1.Value = Session["usrID"].ToString();
        }
        else
        {
            Response.Redirect("CreateAccount.aspx");
        }   
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            if (flUploadImg.HasFile)
            {
                string ext =Path.GetExtension(flUploadImg.PostedFile.FileName);

                string[] allowedExtenstions = new string[] { ".png", ".jpg", ".jpeg" };

                if (allowedExtenstions.Contains(ext))
                {
                    FilNameEx=System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    flUploadImg.SaveAs(MapPath("~/image/userImage/" + FilNameEx + ext));
                    FilNameEx = picEmp.ImageUrl = "~/image/userImage/" + FilNameEx + ext;
                    try
                    {
                        MySqlCommand objCmd = new MySqlCommand("Insert Into tblimgcv(usrIMG,usrID) values(@Img,@Id)",objCon);
                        objCmd.Parameters.AddWithValue("@Img",FilNameEx);
                        objCmd.Parameters.AddWithValue("@Id",HiddenField1.Value.ToString());
                        if (objCmd.ExecuteNonQuery()>0)
                        {
                            lblErr.Text = "Image Uploaded Successfully";
                        }
                        else
                        {
                            lblErr.Text = "Image Uploaded failed";
                        }
                    }
                    catch (Exception objEx)
                    {
                        Response.Write(objEx.ToString());
                    }                    
                    flUploadImg.Visible = false;
                    this.Visible = false;
                }
                else
                {
                    lblErr.Text = "Please Upload Image File Only";
                }
            }                       
        }        
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {       
        if (!flUploadCV.HasFile)
        {
            lblErr.Text = "Problem Occured";
        }
        else if (flUploadCV.HasFile)
        {
            string ext = Path.GetExtension(flUploadCV.PostedFile.FileName);

            string[] allowedExtenstions = new string[] { ".pdf", ".docx", ".doc" };
            if (allowedExtenstions.Contains(ext))
            {
                //if (flUploadCV.FileContent.Length>4000)
                //{
                //    lblErr.Text = "File Length is Very Big";
                //}
                //else
                //{
                    ResumeEx = System.DateTime.Now.ToString("ddMMyyyyhhmmss");
                    flUploadCV.SaveAs(MapPath("~/CV/" + ResumeEx + ext));
                    ResumeEx = "~/CV/" + ResumeEx + ext;
                    try
                    {
                        MySqlCommand objCmd = new MySqlCommand("Update tblimgcv SET usrCV=@cv where usrID=@ID", objCon);
                        objCmd.Parameters.AddWithValue("@cv", ResumeEx);
                        objCmd.Parameters.AddWithValue("@Id", HiddenField1.Value.ToString());
                        if (objCmd.ExecuteNonQuery() > 0)
                        {
                            Session.Abandon();
                            Response.Write("<script>alert('Succesfull In Account Creation Now Please Login');window.location.replace('welcome.aspx');</script>");
                        }
                        else
                        {
                            lblErr.Text = "failed";
                        }
                    }
                    catch (Exception objEx)
                    {
                        Response.Write(objEx.ToString());
                    }                    
                }                             
            }
            else
            {
                lblErr.Text = "Please Upload Resume in PDF,Docx or Doc File Format Only";
            }
        //}
        //else
        //{
        //    lblErr.Text = "Please Upload Resume in PDF,Docx or Doc File Format Only";
        //}
    }
}