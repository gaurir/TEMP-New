﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class WelcomeUserMasterPage : System.Web.UI.MasterPage
{
    MySqlConnection objCon = DbConfig.getConnection();
    int Op = 0;
    protected void Page_Load(object sender, EventArgs e)
    {       
        if (Session["User"] != null && Session["UsrType"] != null && Session["UsrID"] != null)
        {
            string usrType  = "Job Seeker";
            int usrID = Convert.ToInt32(Session["UsrID"].ToString());
            if (Session["UsrType"].Equals(usrType) && usrID != 0)
	        {
                GetUserDetails(Session["User"].ToString(), usrID);
	        }
            else
            {
                Response.Write("welcomeaspx");
            }
        }
        else
        {
            Response.Redirect("welcome.aspx");
        }
    }

    private void GetUserDetails(String userName,int usrID)
    {
        try
        {
            string StrSql = String.Format("select * from tblusrs inner JOIN tblprofessiondetail inner JOIn tblimgcv ON tblusrs.usrId=tblprofessiondetail.usrId where tblusrs.usrId={0}", usrID);
            MySqlCommand objCmd = new MySqlCommand(StrSql,objCon);
            MySqlDataReader objDr = objCmd.ExecuteReader();
            if (objDr.Read())
            {
                hpUser.Text = "Welcome:" + objDr["usrusrname"].ToString().Trim();
                txtName.Text = objDr["usrFName"].ToString().ToUpper() + " " + objDr["usrLName"].ToString().ToUpper()+ "("+objDr["usrAge"].ToString()+")";
                txtIndusry.Text = objDr["usrPrefIndustry"].ToString();
                txtMobile.Text = objDr["usrMobile"].ToString(); ; ;
                txtTitle.Text = objDr["usrTitle"].ToString();
                txtEmail.Text = objDr["usrEmail"].ToString(); ;
                Image1.ImageUrl = objDr["usrIMG"].ToString();
            }
            else
            {
                Response.Redirect("welcome.aspx");
            }
        }
        catch (Exception objEx)
        {
            Response.Write(objEx.ToString());
        }
    }
}
