﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;

/// <summary>
/// Summary description for Mailer
/// </summary>
public class Mailer
{
    private static string strCompanyMailId = "aceeminem@gmail.com".Trim();
    private static string strCompanyPwd = "ashishtiwari@11".Trim();

    public static string SendMail(string To, string subject, string message)
    {
        try
        {
            MailMessage objMail = new MailMessage(strCompanyMailId, To, subject, message);
            objMail.IsBodyHtml = true;
            SmtpClient objSmtp = new SmtpClient("smtp.gmail.com", 587);
            objSmtp.EnableSsl = true;
            objSmtp.Credentials = new System.Net.NetworkCredential(strCompanyMailId, strCompanyPwd);

            objSmtp.Send(objMail);
        }
        catch (Exception objEx)
        {
            return objEx.ToString();
        }
        return "Mail Send to Entered Email Address do check your Mail ID";
    }
}