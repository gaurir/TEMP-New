﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DbConfig
/// </summary>
public class DbConfig
{
    private static MySqlConnection objCon;
    private static MySqlDataReader objDr;
    public static MySqlConnection getConnection()
    {
        try
        {
            if (objCon == null)
            {
                objCon = new MySqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                objCon.Open();
            }
            else
            {
                objCon = new MySqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                objCon.Open();
            }
        }
        catch (Exception objEx)
        {
            Console.WriteLine(objEx.ToString());
        }
        return objCon;
    }

    public static void closeConnection()
    {
        try
        {
            if (objCon.State == ConnectionState.Open)
            {
                objCon.Close();
            }
        }
        catch (MySqlException objEx)
        {
            Console.WriteLine(objEx.ToString());
        }
    }
    //public static bool readData(String strSelectQuery)
    //{
    //    bool blnOutCome = false;
    //    try
    //    {
    //        MySqlCommand objCmd = new MySqlCommand(strSelectQuery, objCon);
    //        objDr = objCmd.ExecuteReader();
    //        if (objDr.HasRows)
    //        {
    //            blnOutCome = true;
    //        }
    //        else
    //        {
    //            blnOutCome = false;
    //        }
    //    }
    //    catch (MySqlException objEx)
    //    {
    //        MessageBox.Show(objEx.ToString(), "MySql Exception", MessageBoxButtons.OK, MessageBoxIcon.Hand);
    //    }
    //    finally
    //    {
    //        closeConnection();
    //    }
    //    return blnOutCome;
    //}

}