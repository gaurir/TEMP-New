﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class ProfessionalDetails : System.Web.UI.Page
{
    MySqlConnection objCon = DbConfig.getConnection();
    int Op = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usrID"] != null)
        {
            HiddenField1.Value = Session["usrID"].ToString();            
        }
        else
        {
            Response.Redirect("CreateAccount.aspx");
        }        
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ddIType.SelectedIndex.Equals(0))
        {
            lblErr.Text = "*Select Proper Industry type from the List*";
        }
        else if (ddFType.SelectedIndex.Equals(0))
        {
            lblErr.Text = "*Select Functional Area in selected Industry type from the List*";
        }
        else if(ddNEyears.SelectedIndex.Equals(0))
        {
            lblErr.Text = "*Please mention number of experience*";
        }
        else
        {
            try
            {
                MySqlCommand objCmd = new MySqlCommand("spFillProfDetails", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("p_usrId", Convert.ToInt32(HiddenField1.Value.Trim()));
                objCmd.Parameters.AddWithValue("p_usrTitle", txtTitle.Text.Trim());
                objCmd.Parameters.AddWithValue("p_usrPrefIndustry", ddIType.SelectedValue.Trim().ToString());
                objCmd.Parameters.AddWithValue("p_usrFunctionalArea", ddFType.SelectedValue.Trim().ToString());
                objCmd.Parameters.AddWithValue("p_usrKeySkill", txtSkills.Text.Trim());
                objCmd.Parameters.AddWithValue("p_usrExp", ddNEyears.SelectedValue.Trim().ToString());
                objCmd.Parameters.AddWithValue("p_usrPCompName", txtPCN.Text.Trim());
                objCmd.Parameters.AddWithValue("p_usrExpInfo", txtPWE.Text.Trim());
                objCmd.Parameters.Add("p_OutRes", MySqlDbType.Int32).Direction = ParameterDirection.Output;
                objCmd.ExecuteNonQuery();
                Op = Convert.ToInt32(objCmd.Parameters["p_OutRes"].Value.ToString());
                switch (Op)
                {
                    case 101:
                        lblErr.Text = "User Profesion Detials already Registered";
                        break;                    
                    case 0:
                        Response.Redirect("UploadLastDetails.aspx");
                        break;
                }
                DbConfig.closeConnection();
            }
            catch (Exception objEx)
            {
                Response.Write(objEx.ToString());
            }
        }
    }
}